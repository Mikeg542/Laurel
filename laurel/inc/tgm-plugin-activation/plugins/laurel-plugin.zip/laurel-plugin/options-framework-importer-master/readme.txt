=== Options Framework Importer ===
Contributors: helgatheviking, vauvarin
Donate link: Donate link: https://inspirepay.com/pay/helgatheviking ‎
Tags: options, theme options, backup, import, export
Requires at least: 3.5.2
Tested up to: 3.5.2
Stable tag: 1.0b
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A standalone plugin version of the import / export system devised by Gilles Vauvarin [@vauvarin](https://github.com/vauvarin) for his [fork of the Options Framework Theme](https://github.com/vauvarin/options-framework-theme)

Admin-level users will see "Import / Export Options" under Appearances if the Options Framework plugin is active.

This is a totally beta plugin, so your mileage may vary.

== Changelog ==

= 1.0b =
* Initial Release
