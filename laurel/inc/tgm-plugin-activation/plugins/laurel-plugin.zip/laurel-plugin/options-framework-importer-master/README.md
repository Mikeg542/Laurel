Options Framework Importer
==========================

A standalone plugin version of the import / export system devised by Gilles Vauvarin [@vauvarin](https://github.com/vauvarin) for his [fork of the Options Framework Theme](https://github.com/vauvarin/options-framework-theme)

Admin-level users will see "Import / Export Options" under Appearances if the Options Framework plugin is active.

This is a totally beta plugin, so your mileage may vary.
