<?php
add_action( 'init', 'slide_post_type' );
function slide_post_type() {  
    $labels = array(
        'name' => __( 'Slides', 'laurel' ),
        'singular_name' => __( 'Slide', 'laurel' ),
        'add_new' => __( 'Add New', 'laurel' ),
        'add_new_item' => __( 'Add New Slide', 'laurel' ),
        'edit_item' => __( 'Edit Slide', 'laurel' ),
        'new_item' => __( 'New Slide', 'laurel' ),
        'view_item' => __( 'View Slide', 'laurel' ),
        'search_items' => __( 'Search Slides', 'laurel' ),
        'not_found' =>  __( 'No Slides found', 'laurel' ),
        'not_found_in_trash' => __( 'No Slides in the trash', 'laurel' ),
        'parent_item_colon' => ''
    );
    register_post_type( 'slides', array(
        'labels' => $labels,
        'singular_label' => __( 'Slide', 'laurel' ),
        'public' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array( 'slug' => 'slideshow' ),	
        'menu_icon' => 'dashicons-images-alt',
        'query_var' => true,
        'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
        'taxonomies' => array( 'post_tag')
    ) );
}

add_action( 'init', 'faq_post_type' );
function faq_post_type() {
    $labels = array(
        'name' => __( 'FAQs', 'laurel' ),
        'singular_name' => __( 'FAQ', 'laurel' ),
        'add_new' => __( 'Add New', 'laurel' ),
        'add_new_item' => __( 'Add New FAQ', 'laurel' ),
        'edit_item' => __( 'Edit FAQ', 'laurel' ),
        'new_item' => __( 'New FAQ', 'laurel' ),
        'view_item' => __( 'View FAQ', 'laurel' ),
        'search_items' => __( 'Search FAQs', 'laurel' ),
        'not_found' =>  __( 'No FAQs found', 'laurel' ),
        'not_found_in_trash' => __( 'No FAQs in the trash', 'laurel' ),
        'parent_item_colon' => ''
    );
    register_post_type( 'FAQs', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'faq-show' ),
        'menu_icon' => 'dashicons-format-chat',
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'editor', 'thumbnail' )        
    ) );
}
add_action( 'init', 'services_post_type' );
function services_post_type() {
    $labels = array(
        'name' => __( 'Services', 'laurel' ),
        'singular_name' => __( 'Service', 'laurel' ),
        'add_new' => __( 'Add New', 'laurel' ),
        'add_new_item' => __( 'Add New Service', 'laurel' ),
        'edit_item' => __( 'Edit Service', 'laurel' ),
        'new_item' => __( 'New Service', 'laurel' ),
        'view_item' => __( 'View Service', 'laurel' ),
        'search_items' => __( 'Search Services', 'laurel' ),
        'not_found' =>  __( 'No Services found', 'laurel' ),
        'not_found_in_trash' => __( 'No Services in the trash', 'laurel' ),
        'parent_item_colon' => ''
    );
    register_post_type( 'services', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'services-show' ),
        'menu_icon' => 'dashicons-admin-tools',
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
	    'supports' => array( 'title', 'editor', 'thumbnail' )
    ) );
}

add_action( 'init', 'testimonials_post_type' );
function testimonials_post_type() {
    $labels = array(
        'name' => __( 'Testimonials', 'laurel' ),
        'singular_name' => __( 'Testimonial', 'laurel' ),
        'add_new' => __( 'Add New', 'laurel' ),
        'add_new_item' => __( 'Add New Testimonial', 'laurel' ),
        'edit_item' => __( 'Edit Testimonial', 'laurel' ),
        'new_item' => __( 'New Testimonial', 'laurel' ),
        'view_item' => __( 'View Testimonial', 'laurel' ),
        'search_items' => __( 'Search Testimonials', 'laurel' ),
        'not_found' =>  __( 'No Testimonials found', 'laurel' ),
        'not_found_in_trash' => __( 'No Testimonials in the trash', 'laurel' ),
        'parent_item_colon' => ''
    );
 
    register_post_type( 'testimonials', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'testimonial-show' ),
        'menu_icon' => 'dashicons-admin-users',
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'register_meta_box_cb' => 'testimonials_meta_boxes' // Callback function for custom metaboxes
    ) );
}

// Enable Meta Boxes for testimonials
function testimonials_meta_boxes() {
    add_meta_box( 'testimonials_form', 'Testimonial Details', 'testimonials_form', 'testimonials', 'normal', 'high' );
}
 
function testimonials_form() {
    $post_id = get_the_ID();
    $testimonial_data = get_post_meta( $post_id, '_testimonial', true );
    $client_name = ( empty( $testimonial_data['client_name'] ) ) ? '' : $testimonial_data['client_name'];
    $source = ( empty( $testimonial_data['source'] ) ) ? '' : $testimonial_data['source'];
    $link = ( empty( $testimonial_data['link'] ) ) ? '' : $testimonial_data['link'];
 
    wp_nonce_field( 'testimonials', 'testimonials' );
    ?>
    <p>
        <label><?php _e( 'Client\'s Name (optional)', 'laurel' ) ?></label><br />
        <input type="text" value="<?php echo $client_name; ?>" name="testimonial[client_name]" size="40" />
    </p>
    <p>
        <label><?php _e( 'Business/Site Name/Location (optional)', 'laurel' ) ?></label><br />
        <input type="text" value="<?php echo $source; ?>" name="testimonial[source]" size="40" />
    </p>
    <p>
        <label><?php _e( 'Link (optional)', 'laurel' ) ?></label><br />
        <input type="text" value="<?php echo $link; ?>" name="testimonial[link]" size="40" />
    </p>
    <?php
}
add_action( 'save_post', 'testimonials_save_post' );
function testimonials_save_post( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
        return;
 
    if ( ! empty( $_POST['testimonials'] ) && ! wp_verify_nonce( $_POST['testimonials'], 'testimonials' ) )
        return;
 
    if ( ! empty( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_page', $post_id ) )
            return;
    } else {
        if ( ! current_user_can( 'edit_post', $post_id ) )
            return;
    }
 
    if ( ! empty( $_POST['testimonial'] ) ) {
        $testimonial_data['client_name'] = ( empty( $_POST['testimonial']['client_name'] ) ) ? '' : sanitize_text_field( $_POST['testimonial']['client_name'] );
        $testimonial_data['source'] = ( empty( $_POST['testimonial']['source'] ) ) ? '' : sanitize_text_field( $_POST['testimonial']['source'] );
        $testimonial_data['link'] = ( empty( $_POST['testimonial']['link'] ) ) ? '' : esc_url( $_POST['testimonial']['link'] );
 
        update_post_meta( $post_id, '_testimonial', $testimonial_data );
    } else {
        delete_post_meta( $post_id, '_testimonial' );
    }
}
add_filter( 'manage_edit-testimonials_columns', 'testimonials_edit_columns' );
function testimonials_edit_columns( $columns ) {
    $columns = array(
        'cb' => '<input type="checkbox" />',
        'title' => __( 'Title', 'laurel' ),
        'testimonial' => __( 'Testimonial', 'laurel' ),
        'testimonial-client-name' => __( 'Client\'s Name', 'laurel' ),
        'testimonial-source' => __( 'Business/Site/Location', 'laurel' ),
        'testimonial-link' => __( 'Link', 'laurel' ),
        'author' => __( 'Posted by', 'laurel' ),
        'date' => __( 'Date', 'laurel' )
    );
 
    return $columns;
}
 
add_action( 'manage_posts_custom_column', 'testimonials_columns', 10, 2 );
function testimonials_columns( $column, $post_id ) {
    $testimonial_data = get_post_meta( $post_id, '_testimonial', true );
    switch ( $column ) {
        case 'testimonial':
            the_excerpt();
            break;
        case 'testimonial-client-name':
            if ( ! empty( $testimonial_data['client_name'] ) )
                echo $testimonial_data['client_name'];
            break;
        case 'testimonial-source':
            if ( ! empty( $testimonial_data['source'] ) )
                echo $testimonial_data['source'];
            break;
        case 'testimonial-link':
            if ( ! empty( $testimonial_data['link'] ) )
                echo $testimonial_data['link'];
            break;
    }
}
?>