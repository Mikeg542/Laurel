<?php
/*
Plugin Name: Laurel Plugin
Plugin URI: http://wordpress.org/plugins/
Description: Contains the shortcodes and custom post types to make the Laurel Theme work to its full potential
Author: Michael Greenwood
Version: 1.0
Author URI: http://m.g
*/

// Laurel Shortcodes
require_once('shortcodes/laurel-shortcodes.php');

// Slide, FAQ, Testimonial and Services custom post types
require_once('post-types/laurel-post-types.php');

//Export / Import Laurel Options
require_once('options-framework-importer-master/options-framework-importer.php');