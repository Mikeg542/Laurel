<?php
add_filter( 'the_content', 'laurel_shortcode_fix' );
function laurel_shortcode_fix( $content ) {
	/** Find all instances of empty paragraph and line break tags */
	$array = array(
		'<p>[' 		=> '[', 
		']</p>' 	=> ']', 
		']<br />'	=> ']',
		'<p></p>' => ''
	);
	/** Replace empty references with corrections */
	$content = strtr( $content, $array );
	return $content;
}

function row_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
  'class' => '' ), $atts );
	$class = $a['class'];
	return '<div class="row ' . $class . '">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'row', 'row_shortcode' );

function clear_shortcode( $atts ) {
	return '<div class="clear"></div>';
}
add_shortcode( 'clear', 'clear_shortcode' );

function line_shortcode( $atts ) {
	return '<hr/>';
}
add_shortcode( 'line', 'line_shortcode' );

function span_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
		'n'  => '',
    'xs' => '',
    'sm' => '',
    'md' => '',
    'lg' => '',
    'class' => '',
    'offset_xs' => '',
    'offset_sm' => '',
    'offset_md' => '',
    'offset_lg' => ''
	), $atts );
	$val = '';
	if ( ! empty( $a['n'] ) ) {
		$val = 'col-md-' . $a['n']; 
	}
	//md takes precedence
	if ( ! empty( $a['md'] ) ) {
		$val = 'col-md-' . $a['md']; 
	}
	if ( ! empty( $a['xs'] ) ) {
		$val .= ' col-xs-' . $a['xs']; 
	}
	if ( ! empty( $a['sm'] ) ) {
		$val .= ' col-sm-' . $a['sm']; 
	}
	if ( ! empty( $a['lg'] ) ) {
		$val .= ' col-lg-' . $a['lg']; 
	}
	if ( ! empty( $a['offset_xs'] ) ) {
		$val .= ' col-xs-offset-' . $a['offset_xs']; 
	}
	if ( ! empty( $a['offset_sm'] ) ) {
		$val .= ' col-sm-offset-' . $a['offset_sm']; 
	}
	if ( ! empty( $a['offset_md'] ) ) {
		$val .= ' col-md-offset-' . $a['offset_md']; 
	}
	if ( ! empty( $a['offset_lg'] ) ) {
		$val .= ' col-lg-offset-' . $a['offset_lg']; 
	}
	$class = $a['class'];
	if ( ! empty( $class ) ) {
		$val .= ' ' . $class;
	}
	return '<div class="' . $val . '">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'span', 'span_shortcode' );

function spacer_shortcode( $atts ) {
	$a = shortcode_atts( array(
    'height' => '' ), $atts );
	$height = $a['height'];
	$style = '';
	if ( ! empty ( $height ) ) {
			$style = 'style="height:' . $height . 'px"';	
	}
	return '<div class="spacer" ' . $style . '></div>';
}
add_shortcode( 'spacer', 'spacer_shortcode' );

function invisible_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
    'sizes' => '' ), $atts );
	if ( ! empty( $a['sizes'] ) )
	{
		$sizes = explode( ',', $a['sizes'] );
		$newclass = '';
		foreach ( $sizes as $val ) {
			$newclass .= ' hidden-' . $val;
		}
	}
	else
	{
		$newclass = 'hidden';
	}
	return '<div class="hide-div' . $newclass . '">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'invisible', 'invisible_shortcode' );

function featurebox_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
    'backgroundcolor' => '',
    'bordercolor' => '',
    'backgroundimage' => '',
    'fixed' => '',
    'nontile' => '',
    'class' => ''
	), $atts );
	$styles = 'style="';
	if ( ! empty( $a['backgroundcolor'] ) || ! empty( $a['bordercolor'] ) || ! empty( $a['backgroundimage'] ) ) {
		if ( ! empty( $a['backgroundcolor'] ) ) {
			$styles .= 'background-color:' . $a['backgroundcolor'] . ';';
		}
		if ( ! empty( $a['bordercolor'] ) ) {
			$styles .= 'border-top: 1px solid ' . $a['bordercolor'] . '; border-bottom: 1px solid ' . $a['bordercolor'] . ';';
		}
		if ( ! empty( $a['backgroundimage'] ) ) {
			$styles .= " background-image: url( '" . $a['backgroundimage'] . "' ); background-repeat: repeat; background-position: center top;";
		}	
		if ( ! empty( $a['backgroundimage'] ) && ! empty( $a['fixed'] ) ) {
			$styles .= ' background-attachment: fixed;';
		}
	}
	$styles .= '"';
	$nontile = '';
	if ( ! empty( $a['nontile'] ) ) {
		$nontile = 'nontile';
	}
	return '<div class="feature-box ' . $a['class'] . ' ' . $nontile . '" ' . $styles . '><div class="container"><div class="row"><div class="col-md-12 featurecontent">' . do_shortcode( $content ) . '</div></div></div></div>';
}
add_shortcode( 'feature_box', 'featurebox_shortcode' );


function collapse_group_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
    'class' => ''
	), $atts );
	$class = '';
	if ( ! empty( $a['class'] ) ) {
		$class = $a['class'];
	}
	return '<div class="panel-group ' . $class . '" id="accordion"><div class="panel panel-default">' . do_shortcode( $content ) . '</div></div>';
}
add_shortcode( 'collapse_group', 'collapse_group_shortcode' );

function collapse_tab_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
    'title' => 'Collapse Item'
	), $atts );
	$href = preg_replace( '/[^A-Za-z0-9 ]/', '', $a['title'] );
	$href = str_replace( ' ', '', $href );
	$output = '';
	$output .= '<div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#' . $href . '">';
  $output .= $a['title'];
  $output .= '</a></h4></div>';
  $output .= '<div id="' . $href . '" class="panel-collapse collapse"><div class="panel-body">';
  $output .= $content;
  $output .= '</div></div>';
	return $output;
}
add_shortcode( 'collapse_tab', 'collapse_tab_shortcode' );

function carousel_shortcode( $atts ) {
	$a = shortcode_atts( array(
    'class' => '',
    'minslides' => '3',
    'maxslides' => '3',
    'slidewidth' => '400'
	), $atts );
	$args = array(
		'post_type'        => 'post',
		'posts_per_page'   => -1,
		'post_status'      => 'publish',
		'orderby'          => 'date',
		'order'            => 'DESC',
		);
	$posts = get_posts($args);
	if (empty($posts)) return;

	$rand = 'bxslider-' . rand(12000, 40000);
	$class = $a['class'];
	$min = $a['minslides'];
	$max = $a['maxslides'];
	$width = $a['slidewidth'];
	$output = '<script>';
	$output .= "jQuery(document).ready(function(){ jQuery('." . $rand . "').bxSlider({
  minSlides: $min,
  maxSlides: $max,
  slideWidth: $width,
  slideMargin: 10
}); });";
	$output .= '</script>';
	$output .= '<ul class="' . $rand . ' ' . $class . '">';
	foreach( $posts as $k => $slide ) {
		$post_data = get_post( $slide->ID );
		if ( has_post_thumbnail( $slide->ID ) ) {
			$sl_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $slide->ID ), 'grid-blog-2col' );
			$output .= '<li><a href="' . get_permalink( $slide->ID ) . '"><img alt="" src="' . $sl_image_url[0] . '" /></a></li>';
		}
	}
	$output .= '</ul>';
	return $output;
}
add_shortcode( 'carousel', 'carousel_shortcode' );

function feature_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
  'class' => '',
  'icon' => '',
  'iconcolor' => '',
  'image' => '',
  'size' => '',
  'title' => '',
  'url' => '',
  'bgcolor' => '',
  'readmoretext' => 'Read More >'
  ), $atts );
	$class = $a['class'];
	$icon = $a['icon'];
	$iconcol = $a['iconcolor'];
	$image = $a['image'];
	$size = $a['size'];
	$title = $a['title'];
	$bgcolor = $a['bgcolor'];
	$url = $a['url'];
	$rmtext = $a['readmoretext'];
	$html = '';
	if ( ! empty ( $content ) || ! empty( $icon ) || ! empty( $image ) ) {
		$html = '<div class="featureitem ' . $class . '"';
		if ( ! empty( $bgcolor ) ) {
			$html .= ' style="background-color: ' . $bgcolor . ';"';
		}
		$html .= '>';		
		if ( ! empty( $icon ) && empty( $image ) ) {
			$html .= '<div class="title"><i style="font-size:' . $size . 'px; color:' . $iconcol . '" class="fa fa-' . $icon . '"></i></div>';
		}
		if ( ! empty( $image ) ) {
			$html .= '<div class="title"><figure><img src="' . $image . '" alt="feature image" /></figure></div>';
		}
		if ( ! empty( $title ) ) {
			$html .= '<h4>' . $title . '</h4>';
		}
		if ( ! empty( $content ) ) {
			$html .= '<div class="text">' . do_shortcode( $content ) . '</div>';
		}
		if ( ! empty( $url ) ) {
			$html .= '<br/><a href="' . $url . '">' . $rmtext . '</a><div style="clear:both"></div><br/>';
		}
		$html .= '</div>';
	}
	return $html;
}
add_shortcode( 'feature_item', 'feature_shortcode' );

function btn_shortcode( $atts, $content = null ) {
$a = shortcode_atts( array(
  'type' => 'default',
  'size' => '',
  'bordercolor' => '',
  'borderwidth' => ''
  ), $atts );
	$size = "btn-" . $a['size'];
	$type = "btn-" . $a['type'];
	$borderstyle = 'style="';
	if ( ! empty( $a['bordercolor'] ) ) {
		$borderstyle .= 'border-color:' . $a['bordercolor'] . '; color: ' . $a['bordercolor'] . ';';
	}
	if ( ! empty( $a['borderwidth'] ) ) {
		$borderstyle .= ' border-width:' . $a['borderwidth'] . 'px;';
	}
	$borderstyle .= '"';
	return '<button type="button" ' . $borderstyle . ' class="btn ' . $type . ' ' . $size . '">' . do_shortcode( $content ) . '</button>';
}
add_shortcode( 'btn', 'btn_shortcode' );

function blockquote_shortcode( $atts, $content = null ) {
$a = shortcode_atts( array(
  'source' => '',
  'reverse' => 'false'
  ), $atts );
	$reverse = $a['reverse'];
	$bqreverse = '';
	$source = $a['source'];
	if ( $reverse != 'false' ) {
		$bqreverse = 'class="blockquote-reverse"';
	}
	$bq = '<blockquote ' . $bqreverse . '>';
	$bq .= do_shortcode($content);
	if ( ! empty( $source ) ) {
		$bq .= '<footer>' . $source . '</footer>';
	}
	$bq .= '</blockquote>';
	return $bq;
}
add_shortcode( 'blockquote', 'blockquote_shortcode' );

function progressbar_shortcode( $atts, $content = null ) {
$a = shortcode_atts( array(
  'striped' => 'false',
  'style' => '',
  'progress' => '50',
  'active' => 'false'
  ), $atts );
	$striped = $a['striped'];
	$active = '';
	$style = $a['style'];
	if ($striped != 'false') {
		$striped = 'progress-bar-striped';
	}
	if ( ! empty( $style ) ) {
		$style = 'progress-bar-' . $style;
	}
	if ( $a['active'] == 'true' ) {
		$active = 'active';
	}
	$progress = $a['progress'];
	if ( ! empty ( $progress ) ) {
		$prb = '<div class="progress">';
	  $prb .= '<div class="progress-bar ' . $style . ' ' . $striped . ' ' . $active . '" role="progressbar" aria-valuenow="' . $progress . '" aria-valuemin="0" aria-valuemax="100" style="width: ' . $progress . '%">';
	  $prb .= $content;
	  $prb .= '</div></div>';
		return $prb;
	}
}
add_shortcode( 'progressbar', 'progressbar_shortcode' );

function alert_shortcode( $atts, $content=null ) {
	$a = shortcode_atts( array(
  	'type' => 'success',
 		'dismissible' => ''
  ), $atts );
	$dismissible = $a['dismissible'];
	if ( ! empty( $a['dismissible'] ) ) {
		$dismissible = 'alert-dismissable';
	}
	$type = 'alert-' . $a['type'];
	$alert = '<div class="alert ' . $type . ' ' . $dismissible . '" role="alert">';
	if ( ! empty( $a['dismissible'] ) ) {
			$alert .= '<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>';
	}
	$alert .= $content;
	$alert .= '</div>';
	return $alert;
}
add_shortcode( 'alert', 'alert_shortcode' );

function dropcap_shortcode( $atts, $content = null ) {
	$output = '<span class="dropcap">';
	$output .= do_shortcode( $content );
	$output .= '</span>';
	return $output;
}
add_shortcode( 'dropcap', 'dropcap_shortcode' );

function biglist_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
  	'bgcolor' => '',
 		'color' => ''
  ), $atts );
	$output = '<span class="big-list" style="';
	if ( ! empty( $a['bgcolor'] ) ) {
		$output .= 'background-color:' . $a['bgcolor'] . ';';
	}
	if ( ! empty( $a['color'] ) ) {
		$output .= ' color:' . $a['color'] . ';';
	}
	$output .= '">';
	$output .= $content;
	$output .= '</span>';
	return $output;
}
add_shortcode( 'biglist', 'biglist_shortcode' );

function postbox_shortcode( $atts ) {
	$a = shortcode_atts( array(
    'class' => '',
    'type' => 'post',
    'category' => '',
    'color' => '#ffffff',
    'bgcolor' => '#212121',
    'hoverbg' => 'orange',
    'num' => '-1',
    'perrow' => '3'
	), $atts );

	$class = $a['class'];
	$category = $a['category']; 
	$type = $a['type'];
	$num = $a['num'];
	$perrow = $a['perrow'];
	$color = $a['color'];
	$bgcolor = $a['bgcolor'];
	$hoverbg = $a['hoverbg'];

	$args = array(
		'post_type'        => $type,
		'category_name'    => $category,
		'posts_per_page'   => $num,
		'post_status'      => 'publish',
		'orderby'          => 'date',
		'meta_key'         => '_thumbnail_id', 
		'order'            => 'DESC',
	);

	$posts = get_posts( $args );
	if ( empty( $posts ) ) return;

	$cols = 'col-sm-' . floor( 12 / $perrow );
	$output = '<style>.post-box .post-item:hover strong { background-color: ' . $hoverbg . ' !important; }';
	$output .= '.post-box:hover .post-item:hover em { color: ' . $bgcolor . ' !important; }';
	$output .= '</style>';
	$output .= '<div class="post-box">';
	foreach( $posts as $k => $post ) {
		if ( has_post_thumbnail( $post->ID ) ) {
			$output .= '<div class="' . $cols . ' ' . $class . ' post-item"><a href="' . get_permalink( $post->ID ) .'">';
			$post_data = get_post( $post->ID );
			$sl_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'grid-blog-2col' );
			$output .= '<img alt="" src="' . $sl_image_url[0] . '" />';
			$output .= '<div class="title-box">';
			$title = get_the_title( $post->ID );
			$titleparts = explode( ' ', $title );
			$last = array_pop( $titleparts );
			$rest = implode( ' ', $titleparts );
			$output .= '<span style="color: ' . $color . ';">' . $rest . '</span>';
			$output .= ' <em style="color: ' . $hoverbg . ';">' . $last . '</em>';
			$output .= '<strong style="background-color: ' . $bgcolor . '; opacity: 0.7;"></strong>';
			$output .= '</div>';
			$output .= '</a></div>';
		}
	}
	$output .= '</div>';
	return $output;
}
add_shortcode( 'post_box', 'postbox_shortcode' );

function tabs_group_shortcode( $atts, $content = null ) {
	if ( ! empty ( $atts ) ) {
		$class = '';
		$type = '';
		if ( ! empty( $atts['class'] ) ) {
			$class = $atts['class'];
		}
		if ( ! empty( $atts['type'] ) ) {
			$type= 'framed';
		}
		$html = '<div class="' . $class . '">';
		$html .= '<ul class="nav nav-tabs" role="tablist">';
		foreach ( $atts as $tabname => $tabs ) {
			$active = '';
			if ( $tabname == 'tab1' ) {
				$active = 'class = "active"';
			}
			if ( strpos( $tabname, 'tab' ) !== false ) {
				$html .= '<li role="presentation" ' . $active . '><a href="#' . $tabname . '" aria-controls="' . $tabname . '" role="tab" data-toggle="tab">' . $tabs . '</a></li>';
			}
		}
		$html .= '</ul><div class="tab-content ' . $type . '">' . do_shortcode( $content ) . '</div></div>';
	}
	return $html;
}
add_shortcode( 'tabs', 'tabs_group_shortcode' );

function tab_shortcode( $atts, $content=null, $shortcodename = "" ) {
	$active = '';
	if ( $shortcodename == 'tab1' ) {
		$active = 'active';
	}
	$html = '<div role="tabpanel" class="tab-pane ' . $active . '" id="' . $shortcodename . '">' . do_shortcode( $content ) . '</div>';
	return $html;
}
add_shortcode( 'tab1', 'tab_shortcode' );
add_shortcode( 'tab2', 'tab_shortcode' );
add_shortcode( 'tab3', 'tab_shortcode' );
add_shortcode( 'tab4', 'tab_shortcode' );
add_shortcode( 'tab5', 'tab_shortcode' );
add_shortcode( 'tab6', 'tab_shortcode' );
add_shortcode( 'tab7', 'tab_shortcode' );
add_shortcode( 'tab8', 'tab_shortcode' );

function box_shortcode( $atts, $content = null ) {
$a = shortcode_atts( array(
	'class' => '',
  'bgcolor' => 'white',
  'color' => 'black',
  'bordercolor' => 'black',
  'borderwidth' => '1px',
  'borderstyle' => 'solid'
  ), $atts );
	$style = 'style="';
	if ( ! empty ( $a['bgcolor'] ) ) {
		$style .= 'background-color:' . $a['bgcolor'] . '; ';
	}
	if ( ! empty ( $a['color'] ) ) {
		$style .= 'color:' . $a['color'] . '; ';
	}
	if ( ! empty ( $a['bordercolor'] ) ) {
		$style .= 'border-color:' . $a['bordercolor'] . '; ';
	}
	if ( ! empty ( $a['borderwidth'] ) ) {
		$style .= 'border-width:' . $a['borderwidth'] . ';';
	}
	if ( ! empty ( $a['borderstyle'] ) ) {
		$style .= 'border-style:' . $a['borderstyle'] . ';';
	}
	$style .= '"';
	$output = '<div class="box';
	if ( ! empty ( $a['class'] ) ) {
		$output .= ' ' . $a['class'];
	}
	$output .= '" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	return $output;
}
add_shortcode( 'box', 'box_shortcode' );

function animate_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
  	'infinite' => '',
 		'effect' => 'bounce',
 		'delay' => '0',
 		'duration' => '2',
 		'repeats' => ''
  ), $atts );
	$output = '<div class="wow ';
	if ( ! empty( $a['effect'] ) ) {
		$output .= $a['effect'];
	}
	if ( ! empty( $a['infinite'] ) ) {
		$output .= ' infinite';
	}
	$output .= '"';
	if ( ! empty( $a['delay'] ) ) {
		$output .= ' data-wow-delay="' . $a['delay'] . 's"';
	}
	if ( ! empty( $a['duration'] ) ) {
		$output .= ' data-wow-duration="' . $a['duration'] . 's"';
	}
	if ( ! empty( $a['repeats'] ) ) {
		$output .= ' data-wow-iteration="' . $a['repeats'] . '"';
	}
	$output .= '>';
	$output .= do_shortcode( $content );
	$output .= '</div>';
	return $output;
}
add_shortcode( 'animate', 'animate_shortcode' );
?>